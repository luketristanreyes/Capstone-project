# Air-quality data cleaning (Queen Street & Patumahoe)

Python pipeline that removes **errors, missing values, duplicates and
inconsistencies** from the four filtered Auckland air-quality dashboard extracts
before they are loaded into Power BI / R Shiny.

| Input file (`data/raw/`) | Site | Years | Parameters |
|---|---|---|---|
| `1C.-Dashboard_data_Queen-Street_filtered.xlsx` | QUS | 2019–2023 | NO2, RH, Temp, WD, WS |
| `1C.-Dashboard_data_Patumahoe_filtered.xlsx` | PAT | 2020–2024 | NOx, NO2, O3 |
| `2C.-Dashboard_data_Patumahoe_filtered.xlsx` | PAT | 2024 (Mar–Apr) | NOx, NO2, O3 |
| `2C.-Dashboard_data_Queen-Street_filtered_2019-2023.xlsx` | QUS | 2019–2023 | NO2, RH, Temp, WD, WS |

## Quick start

```bash
git clone <your-remote-url> air-quality-cleaning
cd air-quality-cleaning
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# put the four .xlsx files in data/raw/, then
python clean_air_quality.py
pytest -q                                           # 15 unit tests
```

Clean a specific file: `python clean_air_quality.py --files data/raw/my_file.xlsx`

## What the pipeline does

The rules run in this order. Each one is logged, and every removed row is written to
`output/<file>_removed.csv` with its reason.

| # | Category | Rule | Default |
|---|---|---|---|
| 1 | Inconsistency | Trim spaces and upper-case site codes; map parameter labels to one spelling (`TEMP` → `Temp`, `NOX` → `NOx`) | on |
| 1 | Error | Remove unknown parameter labels | on |
| 2 | Error | Remove invalid dates, unreadable times (e.g. `1:10:00:00 am am`), non-numeric values | on |
| 3 | Missing | Remove blank values and blank site/time/parameter | on |
| 4 | Duplicate | Remove exact duplicate rows, keeping one copy | on |
| 4 | Duplicate | Same Site+Date+Time+Parameter with **different** values | `drop` (or `mean` / `first`) |
| 5 | Inconsistency | Average sub-hourly readings (10-min RH) to hourly | on |
| 6 | Error | Negative gas concentrations | `drop` (or `clip` / `keep`) |
| 6 | Error | Values outside physical limits (RH 0–100 %, WD 0–360°, WS 0–40 m/s, Temp −10–45 °C, gases ≥ 0) | on |
| 6 | Error | Placeholder zeros: `Temp = 0.0` (logger outage) plus `WD`/`WS = 0` at the same timestamp | on |
| 7 | — | Add a `Datetime` column; sort by Site, Parameter, Datetime | on |

All thresholds and policies are in **`config.yaml`**, so no code changes are needed.

## Outputs (`output/`)

| File | Contents |
|---|---|
| `<file>_clean.xlsx` | `Main` sheet (Site, Date, Time, Datetime, Parameter, Value) + `Cleaning_Log` sheet |
| `<file>_clean.csv` | Same data as CSV, ready for Power BI / R / Python |
| `<file>_removed.csv` | Every removed row with `Category` and `Reason` (audit trail) |
| `all_sites_clean.csv` | All four cleaned files stacked, with a `Source` column |
| `cleaning_report.md` | Row counts per rule and per file |

`Rows in = Rows out + Removed + Merged`. Merged rows are sub-hourly readings that
were averaged into one hourly value.

## Results on the current files

| File | Rows in | Rows out | Removed | Merged | Main issues |
|---|---:|---:|---:|---:|---|
| 1C Queen Street | 180,715 | 139,314 | 39,201 | 2,200 | 37,201 exact duplicates (Temp copied 2–3×); 496 garbled RH times; 941 conflicting RH midnight values; 2,231 ten-minute RH readings averaged to hourly; 563 placeholder zeros |
| 1C Patumahoe | 100,271 | 96,131 | 4,140 | 0 | 4,140 negative NO2/NOx readings (down to −1.5) |
| 2C Patumahoe | 4,392 | 4,181 | 211 | 0 | 211 blank values |
| 2C Queen Street | 62,710 | 62,621 | 89 | 0 | 728 `TEMP` renamed to `Temp`; 88 blanks; 1 impossible wind speed (52.8 m/s) |

## Decisions to review

* **Negative NO2/NOx at Patumahoe** are removed by default. They are small
  instrument-noise values near zero. If removing them would bias low-concentration
  averages, set `negative_values: clip` to replace values between −2 and 0 with 0.
* **Conflicting duplicates** are dropped because the true value can't be
  known. Set `conflicting_duplicates: mean` to average them instead.
* **Midnight (00:00) convention**: the data is kept as recorded. If your source
  uses hour-ending times (00:00 = 24:00 of the previous day), adjust `Datetime`
  before computing daily averages.

## Git workflow

```bash
git checkout -b feature/new-rule      # make changes on a branch
pytest -q                             # tests must pass
git add -A && git commit -m "Add new cleaning rule"
git push -u origin feature/new-rule   # open a pull request
```

Raw Excel files and generated outputs are excluded via `.gitignore`. Remove those
lines if you want them versioned (or use Git LFS for the `.xlsx` files).
