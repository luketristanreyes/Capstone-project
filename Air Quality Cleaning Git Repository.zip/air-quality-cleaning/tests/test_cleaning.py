"""Unit tests for clean_air_quality.Cleaner. Run with:  pytest -q"""
import datetime as dt
from pathlib import Path

import pandas as pd
import pytest

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from clean_air_quality import Cleaner, load_config  # noqa: E402

CFG = load_config(Path(__file__).resolve().parents[1] / "config.yaml")
D = pd.Timestamp("2022-07-01")


def frame(rows):
    return pd.DataFrame(rows, columns=["Site", "Date", "Time", "Parameter", "Value"])


def run(rows, **overrides):
    cfg = {**CFG, **overrides}
    return Cleaner(cfg).run(frame(rows))


def test_parameter_aliases_and_site_case():
    r = run([[" qus ", D, dt.time(1), "TEMP", 15.0], ["QUS", D, dt.time(2), "nox", 10.0]])
    assert set(r.clean["Parameter"]) == {"Temp", "NOx"}
    assert set(r.clean["Site"]) == {"QUS"}


def test_unknown_parameter_removed():
    r = run([["QUS", D, dt.time(1), "Banana", 1.0]])
    assert r.clean.empty and r.removed["Reason"].iloc[0] == "Unknown parameter label"


def test_unreadable_time_removed_and_text_time_parsed():
    r = run([["QUS", D, "1:10:00:00 am am", "RH", 50.0], ["QUS", D, "13:00", "RH", 60.0]])
    assert len(r.clean) == 1 and r.clean["Time"].iloc[0] == dt.time(13)


def test_missing_and_non_numeric_values_removed():
    r = run([["QUS", D, dt.time(1), "NO2", None], ["QUS", D, dt.time(2), "NO2", "n/a"],
             ["QUS", D, dt.time(3), "NO2", 5.0]])
    assert len(r.clean) == 1
    assert set(r.removed["Category"]) == {"Missing", "Error"}


def test_exact_duplicates_keep_one():
    row = ["QUS", D, dt.time(1), "Temp", 20.0]
    r = run([row, row, row])
    assert len(r.clean) == 1 and (r.removed["Reason"] == "Exact duplicate row").sum() == 2


@pytest.mark.parametrize("policy,expected", [("drop", 0), ("first", 1), ("mean", 1)])
def test_conflicting_duplicates(policy, expected):
    rows = [["QUS", D, dt.time(0), "RH", 50.0], ["QUS", D, dt.time(0), "RH", 60.0]]
    r = run(rows, conflicting_duplicates=policy)
    assert len(r.clean) == expected
    if policy == "mean":
        assert r.clean["Value"].iloc[0] == 55.0


def test_sub_hourly_averaged():
    rows = [["QUS", D, dt.time(1, m), "RH", v] for m, v in ((10, 80.0), (20, 82.0), (30, 84.0))]
    r = run(rows)
    assert len(r.clean) == 1 and r.clean["Value"].iloc[0] == 82.0
    assert r.clean["Time"].iloc[0] == dt.time(1)


@pytest.mark.parametrize("policy,n_out,val", [("drop", 0, None), ("clip", 1, 0.0), ("keep", 1, -1.5)])
def test_negative_policy(policy, n_out, val):
    r = run([["PAT", D, dt.time(1), "NO2", -1.5]], negative_values=policy)
    assert len(r.clean) == n_out
    if val is not None:
        assert r.clean["Value"].iloc[0] == val


def test_out_of_range_removed():
    r = run([["QUS", D, dt.time(1), "WS", 52.8], ["QUS", D, dt.time(2), "RH", 101.0],
             ["QUS", D, dt.time(3), "WD", 200.0]])
    assert list(r.clean["Parameter"]) == ["WD"]


def test_placeholder_zero_removes_linked_wind_zeros_only_at_same_time():
    rows = [["QUS", D, dt.time(1), "Temp", 0.0], ["QUS", D, dt.time(1), "WS", 0.0],
            ["QUS", D, dt.time(1), "WD", 0.0], ["QUS", D, dt.time(2), "WS", 0.0]]
    r = run(rows)
    assert len(r.clean) == 1 and r.clean["Time"].iloc[0] == dt.time(2)  # genuine calm kept


def test_datetime_column_and_no_duplicate_keys():
    rows = [["QUS", D, dt.time(h), "NO2", float(h)] for h in range(24)] * 2
    r = run(rows)
    assert r.clean["Datetime"].iloc[5] == D + pd.Timedelta(hours=5)
    assert not r.clean.duplicated(["Site", "Datetime", "Parameter"]).any()
